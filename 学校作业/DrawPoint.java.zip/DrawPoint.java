
import java.util.Scanner;

class Point2D {
	protected double x;
	protected double y;

}

class Point3D extends Point2D {
	protected double z;

}

public class DrawPoint {
	public static void draw(Point2D p[]) {

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double x, y, z;
		Point2D p[] = new Point2D[4];
		for (int i = 0; i < p.length; ++i) {
			// if ((int) (Math.random() * 100) % 2 == 0) {
			if (i % 2 == 0) {
				System.out.println("Enter x y coordinates: ");
				x = sc.nextDouble();
				y = sc.nextDouble();
				p[i] = new Point2D(x, y);
			} else {
				System.out.println("Enter x y z coordinates: ");
				x = sc.nextDouble();
				y = sc.nextDouble();
				z = sc.nextDouble();
				p[i] = new Point3D(x, y, z);
			}
		}
		sc.close();
		draw(p);
	}
}
