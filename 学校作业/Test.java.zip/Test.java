
import java.util.Scanner;

class Person {
	protected String name;
	protected int age;
	protected boolean gender; // true: male

	
}

class Student extends Person {
	protected String stuID;
	protected int chinese;
	protected int math;
	protected int english;

	
}

public class Test {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Student s[] = new Student[3];
		
		// s[0] = new Student("Alice", 20, false, "100", 90, 80, 70);
		// s[1] = new Student("Bob", 21, true, "101", 60, 70, 80);
		// s[2] = new Student("Carter", 22, true, "102", 90, 92, 100);
		for (int i = 0; i < s.length; ++i) {
			String name = sc.next();
			int age = sc.nextInt();
			boolean gender = sc.nextBoolean();
			String stuID = sc.next();
			int chinese = sc.nextInt();
			int math = sc.nextInt();
			int english = sc.nextInt();
			
			s[i] = new Student(name,age,gender,stuID,chinese,math,english);
		}
		sc.close();
		
		for (int i = 0; i < s.length; ++i) {
			System.out.println(s[i]);
		}
	}
}
